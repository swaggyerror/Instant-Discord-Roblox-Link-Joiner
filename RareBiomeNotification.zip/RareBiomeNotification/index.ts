import { showNotification } from "@api/Notifications";
import { definePluginSettings, Settings } from "@api/Settings";
import definePlugin, { OptionType } from "@utils/types";
import { findByPropsLazy, findExportedComponentLazy } from "@webpack";
import { Button, ChannelStore, Forms, GuildStore, NavigationRouter, React, TextInput } from "@webpack/common";
import type { ReactNode } from "react";

const UserSettingsActionCreators = findByPropsLazy("openUserSettings", "USER_SETTINGS_MODAL_KEY");
const HeaderBarIcon = findExportedComponentLazy("Icon", "Divider");


const AUTHOR = {
    name: "Rare Biome Notifier",
    id: 865636057960677439n
};

interface MessageCreateEvent {
    type: "MESSAGE_CREATE";
    message: {
        id: string;
        channel_id: string;
        guild_id?: string;
        content?: string;
        embeds?: Array<{
            title?: string;
            description?: string;
            fields?: Array<{
                name?: string;
                value?: string;
            }>;
            footer?: {
                text?: string;
            };
            author?: {
                name?: string;
            };
        }>;
    };
}

interface WatchTarget {
    guildId: string;
    channelId: string;
}

const DEFAULT_KEYWORDS = [
    "GLITCHED BIOME Started",
    "DREAMSPACE Biome Started",
    "CYBERSPACE Biome Started"
].join("\n");

const TOOLBAR_ICON = "https://cdn.discordapp.com/attachments/1239547514873577473/1509542347783012372/755.png?ex=6a198e5d&is=6a183cdd&hm=5b3374da08a112f00dfaba236fe940d826b33795617cd610d19bbf7be64d3896&animated=true";
const GLITCHED_ICON = "https://media.discordapp.net/attachments/1404929842268606525/1509520780130648155/GLITCHED.png?ex=6a197a47&is=6a1828c7&hm=d91b8dc686dc67cfd0900c97d388688de18fdbf6635b79d979934e3f8e62cde0&animated=true";
const DREAMSPACE_ICON = "https://media.discordapp.net/attachments/1404929842268606525/1509520780596351087/DREAMSPACE.png?ex=6a197a47&is=6a1828c7&hm=6f657b5343a9f40881c2bc1ad66d9f375930187bf9e416e4b07858824282f317&animated=true";
const CYBERSPACE_ICON = "https://media.discordapp.net/attachments/1404929842268606525/1509520779270684858/CYBERSPACE.png?ex=6a197a47&is=6a1828c7&hm=01796e0a181acfbf44dbe34109edd052ce5186d8c3eebb808d7ea84595c9e249&animated=true";
const NOTIFICATION_TIMEOUT_MULTIPLIER = 4;

const RARE_BIOMES = ["GLITCHED", "DREAMSPACE", "CYBERSPACE"] as const;

type RareBiomeName = typeof RARE_BIOMES[number];

const emptyTarget = (): WatchTarget => ({
    guildId: "",
    channelId: ""
});

function parseTargets(rawTargets: string): WatchTarget[] {
    try {
        const targets = JSON.parse(rawTargets);
        if (!Array.isArray(targets)) return [];

        return targets
            .filter(target => target && typeof target.guildId === "string" && typeof target.channelId === "string")
            .map(({ guildId, channelId }) => ({
                guildId: guildId.trim(),
                channelId: channelId.trim()
            }))
            .filter(({ guildId, channelId }) => guildId && channelId);
    } catch {
        return [];
    }
}

function saveTargets(targets: WatchTarget[]) {
    settings.store.targets = JSON.stringify(targets);
}

function getKeywords() {
    return settings.store.keywords
        .split("\n")
        .map(keyword => keyword.trim())
        .filter(Boolean);
}

function getMessageText(message: MessageCreateEvent["message"]) {
    const embedText = message.embeds?.flatMap(embed => [
        embed.title,
        embed.description,
        embed.author?.name,
        embed.footer?.text,
        ...(embed.fields?.flatMap(field => [field.name, field.value]) ?? [])
    ]) ?? [];

    return [message.content, ...embedText]
        .filter(Boolean)
        .join("\n");
}

function getGuildId(message: MessageCreateEvent["message"]) {
    return message.guild_id ?? ChannelStore.getChannel(message.channel_id)?.guild_id;
}

function getTarget(message: MessageCreateEvent["message"]) {
    const guildId = getGuildId(message);
    if (!guildId) return null;

    return parseTargets(settings.store.targets)
        .find(target => target.guildId === guildId && target.channelId === message.channel_id) ?? null;
}

function getMatchedKeyword(messageText: string) {
    const lowerMessageText = messageText.toLowerCase();
    const customKeyword = getKeywords().find(keyword => lowerMessageText.includes(keyword.toLowerCase()));
    if (customKeyword) return customKeyword;

    const upperMessageText = messageText.toUpperCase();
    const matchedBiome = RARE_BIOMES.find(biomeName => upperMessageText.includes(biomeName));
    if (!matchedBiome) return;

    if (/\bFOUND\b/.test(upperMessageText))
        return `${matchedBiome} Biome Found`;

    if (/\bSTARTED\b/.test(upperMessageText))
        return `${matchedBiome} Biome Started`;
}

function getBiomeName(matchedKeyword: string): RareBiomeName | undefined {
    const upperKeyword = matchedKeyword.toUpperCase();
    return RARE_BIOMES.find(biomeName => upperKeyword.includes(biomeName));
}

function getBiomeIcon(matchedKeyword: string) {
    switch (getBiomeName(matchedKeyword)) {
        case "GLITCHED":
            return GLITCHED_ICON || TOOLBAR_ICON || undefined;
        case "DREAMSPACE":
            return DREAMSPACE_ICON || TOOLBAR_ICON || undefined;
        case "CYBERSPACE":
            return CYBERSPACE_ICON || TOOLBAR_ICON || undefined;
        default:
            return TOOLBAR_ICON || undefined;
    }
}

function openMessage(guildId: string, channelId: string, messageId: string) {
    window.focus();
    NavigationRouter.transitionTo(`/channels/${guildId}/${channelId}/${messageId}`);
}

function showRareBiomeNotification(options: Parameters<typeof showNotification>[0]) {
    const oldTimeout = Settings.notifications.timeout;
    const oldUseNative = Settings.notifications.useNative;
    const longerTimeout = (oldTimeout || 5000) * NOTIFICATION_TIMEOUT_MULTIPLIER;

    Settings.notifications.timeout = longerTimeout;
    Settings.notifications.useNative = "never";
    showNotification({
        ...options,
        permanent: false,
        dismissOnClick: true
    });

    setTimeout(() => {
        if (Settings.notifications.timeout === longerTimeout)
            Settings.notifications.timeout = oldTimeout;
        if (Settings.notifications.useNative === "never")
            Settings.notifications.useNative = oldUseNative;
    }, longerTimeout + 1000);
}

function openPluginSettings() {
    try {
        Vencord.Components.openPluginModal(Vencord.Plugins.plugins["Rare Biome Notifier"]);
    } catch { }
}

function notifyBiome(message: MessageCreateEvent["message"], guildId: string, matchedKeyword: string) {
    const guild = GuildStore.getGuild(guildId);
    const channel = ChannelStore.getChannel(message.channel_id);

    showRareBiomeNotification({
        title: "Rare Biome Notifier",
        body: `${matchedKeyword}${guild?.name ? ` in ${guild.name}` : ""}${channel?.name ? ` #${channel.name}` : ""}`,
        icon: getBiomeIcon(matchedKeyword),
        onClick: () => openMessage(guildId, message.channel_id, message.id)
    });
}

function TopBarIcon() {
    return React.createElement(HeaderBarIcon, {
        tooltip: "Rare Biome Notifier",
        icon: () => TOOLBAR_ICON
            ? React.createElement("img", {
                src: TOOLBAR_ICON,
                alt: "",
                style: {
                    width: "20px",
                    height: "20px",
                    borderRadius: "4px",
                    objectFit: "cover"
                }
            })
            : React.createElement("svg", {
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                fill: "currentColor"
            }, React.createElement("path", {
                d: "M12 2 9.75 8.75 3 11l6.75 2.25L12 20l2.25-6.75L21 11l-6.75-2.25L12 2Zm0 5.4.98 2.94.16.48.48.16 2.94.98-2.94.98-.48.16-.16.48L12 16.6l-.98-2.94-.16-.48-.48-.16-2.94-.98 2.94-.98.48-.16.16-.48L12 7.4Z"
            })),
        onClick: openPluginSettings
    });
}

function ToolbarWrapper({ children }: { children: ReactNode[]; }) {
    children.splice(
        Math.max(children.length - 1, 0),
        0,
        React.createElement(TopBarIcon, { key: "rare-biome-notifier-toolbar" })
    );

    return React.createElement(
        React.Fragment,
        null,
        children
    );
}

function TargetRow({ index, target, targets, setTargets }: {
    index: number;
    target: WatchTarget;
    targets: WatchTarget[];
    setTargets: (targets: WatchTarget[]) => void;
}) {
    const updateTarget = (patch: Partial<WatchTarget>) => {
        const nextTargets = [...targets];
        nextTargets[index] = { ...target, ...patch };
        setTargets(nextTargets);
        saveTargets(nextTargets);
    };

    const removeTarget = () => {
        const nextTargets = targets.filter((_, targetIndex) => targetIndex !== index);
        setTargets(nextTargets);
        saveTargets(nextTargets);
    };

    return React.createElement(
        "div",
        { style: { display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: "8px", marginBottom: "8px" } },
        React.createElement(TextInput, {
            placeholder: "Server ID",
            value: target.guildId,
            onChange: (guildId: string) => updateTarget({ guildId })
        }),
        React.createElement(TextInput, {
            placeholder: "Channel ID",
            value: target.channelId,
            onChange: (channelId: string) => updateTarget({ channelId })
        }),
        React.createElement(
            Button,
            {
                color: Button.Colors.RED,
                size: Button.Sizes.SMALL,
                onClick: removeTarget
            },
            "Remove"
        )
    );
}

function TargetsComponent() {
    const [targets, setTargets] = React.useState<WatchTarget[]>(() => {
        const savedTargets = parseTargets(settings.store.targets);
        return savedTargets.length ? savedTargets : [emptyTarget()];
    });

    const addTarget = () => {
        const nextTargets = [...targets, emptyTarget()];
        setTargets(nextTargets);
        saveTargets(nextTargets);
    };

    return React.createElement(
        Forms.FormSection,
        null,
        React.createElement(Forms.FormTitle, { tag: "h3" }, "Rare Biome Notification Targets"),
        React.createElement(
            Forms.FormText,
            null,
            "Add every server/channel pair you want watched. Enable Developer Mode in Discord, then right click a server/channel and use Copy ID."
        ),
        React.createElement(
            "div",
            { style: { marginTop: "12px" } },
            targets.map((target, index) => React.createElement(TargetRow, {
                key: index,
                index,
                target,
                targets,
                setTargets
            }))
        ),
        React.createElement(
            Button,
            {
                color: Button.Colors.BRAND,
                size: Button.Sizes.SMALL,
                onClick: addTarget
            },
            "Add New Server / Channel"
        )
    );
}

const settings = definePluginSettings({
    targetsComponent: {
        type: OptionType.COMPONENT,
        component: TargetsComponent
    },
    targets: {
        type: OptionType.STRING,
        description: "Internal JSON storage for watched server/channel IDs.",
        default: "[]"
    },
    keywords: {
        type: OptionType.STRING,
        description: "Biome phrases to detect, one per line.",
        default: DEFAULT_KEYWORDS
    }
});

export default definePlugin({
    name: "Rare Biome Notifier",
    description: "Get a notification when theres a Rare Biome (MUST CONFIGURE YOURSELF)",
    authors: [AUTHOR],
    tags: ["Notifications", "Servers"],
    settings,
    patches: [
        {
            find: "toolbar:function",
            replacement: {
                match: /(?<=toolbar:function.{0,100}\()\i\.Fragment,/,
                replace: "$self.ToolbarWrapper,"
            }
        }
    ],

    flux: {
        MESSAGE_CREATE(event: MessageCreateEvent) {
            const { message } = event;
            if (!message?.id || !message.channel_id) return;

            const target = getTarget(message);
            if (!target) return;

            const matchedKeyword = getMatchedKeyword(getMessageText(message));
            if (!matchedKeyword) return;

            notifyBiome(message, target.guildId, matchedKeyword);
        }
    },

    ToolbarWrapper
});
