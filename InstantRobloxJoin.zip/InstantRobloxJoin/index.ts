import definePlugin from "@utils/types";
import * as Native from "./native";

let originalWindowOpen: typeof window.open;

type LaunchTarget = {
    kind: "privateServer" | "share";
    sourceUrl: string;
    placeId: string | null;
    linkCode: string;
};

let launchQueue = Promise.resolve();

function getNativeHelper(): typeof Native | undefined {
    const helpers = (VencordNative.pluginHelpers ?? {}) as Record<string, unknown>;
    const directHelper = helpers.InstantRobloxJoin as typeof Native | undefined;

    if (directHelper) return directHelper;

    for (const [key, helper] of Object.entries(helpers)) {
        const candidate = helper as Partial<typeof Native>;

        if (
            typeof candidate.restartRoblox === "function" ||
            typeof candidate.killRoblox === "function" ||
            typeof candidate.resolveRobloxShareLink === "function"
        ) {
            console.log("[InstantRobloxJoin] Using native helper:", key);
            return candidate as typeof Native;
        }
    }

    console.warn("[InstantRobloxJoin] Native helper missing. Available helpers:", Object.keys(helpers));
    return undefined;
}

function launch(url: string) {
    console.log("[InstantRobloxJoin] Launch:", url);
    originalWindowOpen.call(window, url, "_blank");
}

function isRobloxHost(hostname: string) {
    return hostname === "roblox.com" || hostname.endsWith(".roblox.com");
}

function interceptUrl(url: string): boolean {
    const launchTarget = parseLaunchTarget(url);

    if (!launchTarget) return false;

    queueLaunch(launchTarget);

    return true;
}

function parseLaunchTarget(href: string): LaunchTarget | null {
    let url: URL;
    try {
        url = new URL(href);
    } catch {
        return null;
    }

    if (!isRobloxHost(url.hostname)) return null;

    if (url.pathname.includes("/share")) {
        const code = url.searchParams.get("code");
        if (!code) return null;

        return {
            kind: "share",
            sourceUrl: url.toString(),
            placeId: null,
            linkCode: code
        };
    }

    const privateCode = url.searchParams.get("privateServerLinkCode");
    if (!privateCode) return null;

    const match = url.pathname.match(/games\/(\d+)/);
    return {
        kind: "privateServer",
        sourceUrl: url.toString(),
        placeId: match?.[1] ?? null,
        linkCode: privateCode
    };
}

async function launchRoblox(target: LaunchTarget) {
    const native = getNativeHelper();

    if (native?.restartRoblox) {
        const restartResult = await native.restartRoblox(target.kind === "share");
        console.log("[InstantRobloxJoin] Restart result:", restartResult);
    } else if (native?.killRoblox) {
        const killResult = await native.killRoblox();
        console.log("[InstantRobloxJoin] Kill result:", killResult);
    }

    const url = target.placeId
        ? `roblox://experiences/start?placeId=${target.placeId}&linkCode=${target.linkCode}`
        : await getShareLaunchUrl(native, target);

    launch(url);
}

async function getShareLaunchUrl(native: typeof Native | undefined, target: LaunchTarget) {
    if (native?.resolveRobloxShareLink) {
        const resolvedUrl = await native.resolveRobloxShareLink(target.sourceUrl);
        console.log("[InstantRobloxJoin] Share resolver result:", resolvedUrl ?? "fallback");

        if (resolvedUrl) {
            return resolvedUrl;
        }
    }

    return `roblox://navigation/share_links?code=${target.linkCode}&type=Server`;
}

function queueLaunch(target: LaunchTarget) {
    launchQueue = launchQueue
        .catch(() => void 0)
        .then(() => launchRoblox(target))
        .catch(error => {
            console.error("[InstantRobloxJoin] Launch failed:", error);
        });
}

function handleClick(event: MouseEvent) {
    if (event.defaultPrevented || event.button !== 0) return;
    if (event.ctrlKey || event.shiftKey || event.altKey || event.metaKey) return;

    const target = event.target as HTMLElement | null;
    if (!target) return;

    if (target.closest("input, textarea, select, button, [contenteditable='true']")) {
        return;
    }

    const anchor = target.closest("a[href]") as HTMLAnchorElement | null;
    if (!anchor) return;

    const launchTarget = parseLaunchTarget(anchor.href);
    if (!launchTarget) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    queueLaunch(launchTarget);
}

export default definePlugin({
    name: "Instant Roblox Join",
    description: "Immediately launch Roblox links without needing to open a browser.",
    authors: [
        {
            name: "swaggyerror",
            id: 865636057960677439n
        }
    ],

    start() {
        document.addEventListener("click", handleClick, true);

        originalWindowOpen = window.open;

        window.open = function(url?: string | URL, target?: string, features?: string) {
            if (
                typeof url === "string" &&
                (url.startsWith("http://") || url.startsWith("https://")) &&
                interceptUrl(url)
            ) {
                return null;
            }

            return originalWindowOpen.call(window, url, target, features);
        };

        console.log("[InstantRobloxJoin] loaded");
    },

    stop() {
        document.removeEventListener("click", handleClick, true);
        window.open = originalWindowOpen;
    }
});
