import { execFile } from "child_process";
import { get } from "https";
import { URL } from "url";

const ROBLOX_PLAYER_PROCESS = "RobloxPlayerBeta.exe";
const BOOTSTRAPPER_PROCESS = "Bloxstrap.exe";
const POLL_INTERVAL_MS = 100;
const EXIT_TIMEOUT_MS = 5000;
const BOOTSTRAPPER_EXIT_TIMEOUT_MS = 1500;
const POST_EXIT_DELAY_MS = 300;
const SHARE_LINK_RESOLVE_TIMEOUT_MS = 5000;
const MAX_SHARE_LINK_REDIRECTS = 8;

type KillResult = {
    imageName: string;
    beforePids: number[];
    afterPids: number[];
    exited: boolean;
    error?: string;
};

type RestartResult = {
    bloxstrap?: KillResult;
    roblox: KillResult;
};

function execTask(file: string, args: string[]): Promise<string> {
    return new Promise((resolve, reject) => {
        execFile(file, args, { windowsHide: true }, (error, stdout) => {
            if (error) {
                reject(error);
                return;
            }

            resolve(stdout);
        });
    });
}

async function isProcessRunning(imageName: string): Promise<boolean> {
    return (await getProcessIds(imageName)).length > 0;
}

async function getProcessIds(imageName: string): Promise<number[]> {
    const processName = imageName.replace(/\.exe$/i, "");

    try {
        const stdout = await execTask("powershell", [
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            `Get-Process -Name '${processName}' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id`
        ]);

        return stdout
            .split(/\r?\n/)
            .map(line => Number(line.trim()))
            .filter(Number.isInteger);
    } catch {
        return [];
    }
}

function sleep(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForProcessExit(imageName: string, timeoutMs: number) {
    const deadline = Date.now() + timeoutMs;

    while (Date.now() < deadline) {
        if (!(await isProcessRunning(imageName))) {
            return true;
        }

        await sleep(POLL_INTERVAL_MS);
    }

    return !(await isProcessRunning(imageName));
}

async function waitForPidsExit(pids: number[], timeoutMs: number) {
    const deadline = Date.now() + timeoutMs;

    while (Date.now() < deadline) {
        const stillRunning = await Promise.all(pids.map(pid => isPidRunning(pid)));
        if (!stillRunning.some(Boolean)) {
            return true;
        }

        await sleep(POLL_INTERVAL_MS);
    }

    const stillRunning = await Promise.all(pids.map(pid => isPidRunning(pid)));
    return !stillRunning.some(Boolean);
}

async function isPidRunning(pid: number): Promise<boolean> {
    try {
        const stdout = await execTask("powershell", [
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            `if (Get-Process -Id ${pid} -ErrorAction SilentlyContinue) { '1' }`
        ]);

        return stdout.trim() === "1";
    } catch {
        return false;
    }
}

async function forceKillProcess(imageName: string): Promise<KillResult> {
    const pids = await getProcessIds(imageName);
    if (!pids.length) {
        return {
            imageName,
            beforePids: [],
            afterPids: [],
            exited: true
        };
    }

    console.log(`[InstantRobloxJoin] Killing ${imageName}: ${pids.join(", ")}`);

    await Promise.all(pids.map(async pid => {
        try {
            await execTask("powershell", [
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                `Stop-Process -Id ${pid} -Force -ErrorAction SilentlyContinue`
            ]);
        } catch {
            // Fall through to taskkill below.
        }

        try {
            await execTask("taskkill", ["/F", "/T", "/PID", String(pid)]);
        } catch {
            // `taskkill` can still return a non-zero exit code while the process is already closing.
        }

        try {
            await execTask("powershell", [
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                `Get-CimInstance Win32_Process -Filter "ProcessId = ${pid}" | Invoke-CimMethod -MethodName Terminate | Out-Null`
            ]);
        } catch {
            // Final fallback; failure here means Windows is refusing the termination request.
        }
    }));

    const pidsExited = await waitForPidsExit(pids, EXIT_TIMEOUT_MS);
    const imageExited = await waitForProcessExit(imageName, EXIT_TIMEOUT_MS);
    const remainingPids = await getProcessIds(imageName);

    if (!pidsExited || !imageExited) {
        return {
            imageName,
            beforePids: pids,
            afterPids: remainingPids,
            exited: false,
            error: `Timed out waiting for ${imageName} to exit.`
        };
    }

    return {
        imageName,
        beforePids: pids,
        afterPids: remainingPids,
        exited: true
    };
}

export async function killRoblox(): Promise<KillResult> {
    const result = await forceKillProcess(ROBLOX_PLAYER_PROCESS);
    if (result.beforePids.length) await sleep(POST_EXIT_DELAY_MS);
    return result;
}

async function killBloxstrap(): Promise<KillResult> {
    try {
        const result = await forceKillProcess(BOOTSTRAPPER_PROCESS);
        await waitForProcessExit(BOOTSTRAPPER_PROCESS, BOOTSTRAPPER_EXIT_TIMEOUT_MS);
        return result;
    } catch (error) {
        console.warn("[InstantRobloxJoin] Failed to kill Bloxstrap:", error);

        return {
            imageName: BOOTSTRAPPER_PROCESS,
            beforePids: [],
            afterPids: await getProcessIds(BOOTSTRAPPER_PROCESS),
            exited: false,
            error: error instanceof Error ? error.message : String(error)
        };
    }
}

export async function restartRoblox(includeBootstrapper = false): Promise<RestartResult> {
    let bloxstrap: KillResult | undefined;

    if (includeBootstrapper) {
        bloxstrap = await killBloxstrap();
    }

    const roblox = await killRoblox();
    await sleep(POST_EXIT_DELAY_MS);

    return {
        bloxstrap,
        roblox
    };
}

function normalizeRobloxDeepLink(value: string): string | null {
    let current = value.trim();

    for (let i = 0; i < 3; i++) {
        try {
            current = decodeURIComponent(current);
        } catch {
            break;
        }

        if (current.startsWith("roblox://")) {
            return current;
        }
    }

    return current.startsWith("roblox://") ? current : null;
}

function findRobloxDeepLink(value: string): string | null {
    const directMatch = value.match(/roblox%3A%2F%2F[^"'\s<>]+|roblox:\/\/[^"'\s<>]+/i);
    if (directMatch) {
        return normalizeRobloxDeepLink(directMatch[0]);
    }

    try {
        const url = new URL(value);
        const deepLink = url.searchParams.get("deep_link_value") ?? url.searchParams.get("af_dp");

        if (deepLink) {
            return normalizeRobloxDeepLink(deepLink);
        }
    } catch {
        return null;
    }

    return null;
}

function requestUrl(url: string, redirectsLeft = MAX_SHARE_LINK_REDIRECTS): Promise<string | null> {
    return new Promise(resolve => {
        const request = get(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 InstantRobloxJoin",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            },
            timeout: SHARE_LINK_RESOLVE_TIMEOUT_MS
        }, response => {
            const location = response.headers.location;

            if (location) {
                const redirectUrl = new URL(location, url).toString();
                const deepLink = findRobloxDeepLink(redirectUrl);

                if (deepLink || redirectsLeft <= 0) {
                    response.resume();
                    resolve(deepLink);
                    return;
                }

                response.resume();
                requestUrl(redirectUrl, redirectsLeft - 1).then(resolve);
                return;
            }

            const chunks: Buffer[] = [];

            response.on("data", chunk => chunks.push(Buffer.from(chunk)));
            response.on("end", () => {
                resolve(findRobloxDeepLink(Buffer.concat(chunks).toString("utf8")));
            });
        });

        request.on("timeout", () => {
            request.destroy();
            resolve(null);
        });

        request.on("error", () => resolve(null));
    });
}

export async function resolveRobloxShareLink(url: string): Promise<string | null> {
    try {
        return await requestUrl(url);
    } catch {
        return null;
    }
}
